<?php

global $is_logged = false;

function log_in(){
	$is_logged = true;
}

?>